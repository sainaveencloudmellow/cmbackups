<!doctype html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0,maximum-scale=1.0, user-scalable=no">
<link rel="icon" href="images/fav.png">
<title>Infos3cure</title>
<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="css/bootstrap-slider.min.css">
<link rel="stylesheet" type="text/css" href="css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="css/slick.css">
<link rel="stylesheet" type="text/css" href="css/style-blue.css">

<script src='https://www.google.com/recaptcha/api.js'></script>

</head>

<body>

<div id="header-holder" class="inner-header color3-header web-hosting-page">
    <div class="whitebg"><img src="images/whitebg.svg" alt=""></div>
    <nav id="nav" class="navbar navbar-default navbar-full">
        <div class="container-fluid">
            <div class="container container-nav">
                <div class="row">
                    <div class="col-md-12">
                        <div class="navbar-header">
                            <button aria-expanded="false" type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs">
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                            </button>
                           <a class="logo-holder" href="index.php">
                                <div class="logo"></div>
                            </a>
                        </div>
                        <div style="height: 1px;" role="main" aria-expanded="false" class="navbar-collapse collapse" id="bs">
                               <ul class="nav navbar-nav navbar-right">
                                <li><a href="index.php">Home</a></li>
                                
                                   <li class="dropdown">
                                    <a href="index.php#features">Our Services  <i class="fa fa-caret-down"></i></a>
                                    <ul class="dropdown-menu">
                                      <li><a href="infrastructuresec.php">Infrastructure Security</a></li>
                                     <li><a href="applicationsec.php">Application Security</a></li>
                                     
                                    </ul>
                                </li>
                                 <li><a href="index.php#more-features">Our Promise</a></li>
                                  <li><a href="contact.php">Contact Us</a></li>
                               
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </nav>
    <div id="page-head" class="container-fluid inner-page">
        <div class="container">
            <div class="row">
                <div class="col-md-12 text-center">
                    <div class="page-title">Contact Us</div>
                    <div id="page-icon">
                        <div class="pricing-icon pricing-color2">
                            <img src="images/contact.png" style="margin-top: 10px;" alt="">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div id="contact-info" class="container-fluid">
    <div class="container">
        
        <div class="row">
            <div class="col-md-8">
                <div class="info-box">
                    <div class="info-title phone-icon">Give Us A Call</div>
                    <div class="info-details"><p>Speak to One of Our Advisors 
                    @ <a href="tel:3174536991">(317) 453-6991</a></p></div>
                </div>

          
     
        <div class="gmap-area">
            <div class="container">
                <div class="row">

                     <div class="col-md-4 map-content">
                        <ul class="row">
                          


                            <li class="col-md-12">

                                <address>
                                  


                                    <P>9505 E 59th Street, Suite B<br>Indianapolis, IN-46216, USA<br>
                                    
                                   
                                   </p>
                                    
                                </address>
                            <div class="gmap">
                           
                            
                            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d24499.577641358945!2d-86.03112956505447!3d39.864219633702525!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x886b4b88f28afec7%3A0x80a6bb34a7ca72ee!2sIndianapolis%2C+IN+46216!5e0!3m2!1sen!2sus!4v1533928027555"  frameborder="0" style="border:0" allowfullscreen></iframe>

                           

                        </div>
                            
                            </li>
                           
                        </ul>
                    </div>
                    <div class="col-md-4 map-content">
                        <ul class="row">
                          


                            <li class="col-md-12">

                                <address>
                                    

                                    <P>26040 Acero, Suite 111<br>
                                   Mission Viejo, CA -92691, USA<br>
                                    
                                   
                                   
                                     </p>
                                    
                                </address>
                                 <div class="gmap">
                           
                         <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3322.5143637138895!2d-117.67816948517802!3d33.61790288072632!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x80dce910fcedf37b%3A0xa28f871dbe963fce!2s26040+Acero%2C+Mission+Viejo%2C+CA+92691!5e0!3m2!1sen!2sus!4v1533928140590"  frameborder="0" style="border:0" allowfullscreen></iframe>
                        </div>
                            
                            </li>
                           
                        </ul>
                    </div>
            </div>
                   
            </div>
        </div>
      <!--/gmap_area -->
            </div>
            
            <div class="col-md-4">
                <div class="signin-signup-form">
                <div class="form-items">
                    
                    <form role="form" id="contact_send" method="post">
                        <div class="row">
                            <div class="col-md-6 form-text">
                                <input type="text" name="fname" placeholder="First name*" required>
                            </div>
                            <div class="col-md-6 form-text">
                                <input type="text" name="lname" placeholder="Last Name" required>
                            </div>
                        </div>
                        <div class="form-text">
                            <input type="text" name="phone" placeholder="Phone Number*" required>
                        </div>
                        <div class="form-text">
                            <input type="text" name="email" placeholder="E-mail Address*" required>
                        </div>

                        <div class="form-text">
                        <select name="formsubject" required="">
                            <option value="">Subject </option>
                            <option value="cybersec">Cyber Security Maturity Assessment </option>
                            <option value="infrasec">Infrastructure Security</option>
                            <option value="appsec">Application Security</option>
                          </select>
                      </div>

                        <div class="form-text">
                            
                        <textarea name="contactmessage" rows="7" placeholder="Message" class="form-control" id="inputMessage"></textarea>
                        </div>

                        <div class="g-recaptcha" data-sitekey="6LdgOmkUAAAAAIe_ZLdZyScOqNidI0hP78qdzRFD"></div>
                       
                        <div class="form-button">
                            <button id="submit" type="submit" class="ybtn ybtn-accent-color">Submit</button>
                        </div>
                    </form>
                    <div id="get_in_touch_success" class="alert-success"></div>
                </div>
            </div>
            </div>
        </div>
    </div>
</div>


<div id="footer" class="container-fluid">
    <div class="container">
        <div class="row">
            <div class="col-md-3">
                <div class="address-holder">
                    <div class="phone"><i class="fa fa-phone"></i> <a href="tel:3174536991">(317) 453-6991</a></div>
                    <div class="email"><i class="fa fa-envelope"></i><a href="mailto:secure@INFOS3CURE"> secure@INFOS3CURE.com</a></div>
                       <div class="address">
                        <i class="fa fa-map-marker"></i> 
                        <div>26040 Acero, Suite 111<br>
                             Mission Viejo, CA <br>
                           92691, USA</div>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="footer-menu-holder">
                    <h4>Services</h4>
                    <ul class="footer-menu">
                        <li><a href="infrastructuresec.php">Infrastructure Security</a></li>
                        <li><a href="applicationsec.php">Application Security </a></li>
                        
                        
                    </ul>
                </div>
            </div>

                <div class="col-md-3">
                <div class="footer-menu-holder">
                    <h4>Company</h4>
                    <ul class="footer-menu">
                        <li><a href="privacypolicy.php">Privacy Policy</a></li>
                        <li><a href="termsuse.php">Terms of Use </a></li>
                        
                        
                    </ul>
                </div>
            </div>
            

            <div class="col-md-3">
                <div class="footer-menu-holder">
                    <h4>Partnerships</h4>
                    <a href="https://www.symantec.com/" target="_blank"><img src="images/secure-one-registered-partner-logo-global-registered.jpg"></a>
                   
                   
                </div>
            </div>
         
           
            <div class="col-xs-12"><hr>
               <div class="row">
               <div class="col-md-6 bottombar ">

                        <p>© 2018 All Rights Reserved |  <a href="http://infosharesystems.com/" target="_blank">Infoshare Systems Inc</a></p>
                        
                    </div>
                    <!--<div class="col-md-4  ">
                       
                            <div class="social-menu-holder">
                    <ul class="social-menu">
                        <li style="text-align: center;"><a href="#"><i class="fa fa-facebook"></i></a> | <a href="#"><i class="fa fa-linkedin"></i></a> | <a href="#"><i class="fa fa-twitter"></i></a></li>
                    </ul>
                </div>
                    </div>-->
                       <div class="col-md-6 bottombar">
                        <p>Powered By <a href="http://cloudmellow.com/" target="_blank">CloudMellow</a></p>
                    </div>
               </div>
            </div>
        </div>
    </div>
</div>
<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/bootstrap-slider.min.js"></script>
<script src="js/slick.min.js"></script>
<script src="js/main.js"></script>



        <script type="text/javascript">
           //Contact Form
         $(function() {
           $('#contact_send').submit(function(e) {
             e.preventDefault();
           
             $.ajax({
               type: 'POST',
               url: 'testscript/mail.php',
               data: new FormData($('#contact_send')[0]),
               cache: false,
               contentType: false,
               processData: false,
               success: function(response) {
                 $('#get_in_touch_success').html(response);
                  $("#contact_send")[0].reset();
                    console.log('Submitting');
               }
             });
           });
         });
         </script>


        <script type="text/javascript">
           //Contact Form
         $(function() {
           $('#signinform').submit(function(e) {
             e.preventDefault();
             
             $.ajax({
               type: 'POST',
               url: 'php/subscription.php',
               data: new FormData($('#signinform')[0]),
               cache: false,
               contentType: false,
               processData: false,
               success: function(response) {
                 $('#get_in_touch_success2').html(response);
                  $("#signinform")[0].reset();
                  console.log('Submitting');
               }
             });
           });
         });
         </script>


</body>
</html>
