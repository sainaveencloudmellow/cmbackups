<!doctype html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0,maximum-scale=1.0, user-scalable=no">
<link rel="icon" href="images/fav.png">
<title>INFOS3CURE</title>
<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="css/bootstrap-slider.min.css">
<link rel="stylesheet" type="text/css" href="css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="css/slick.css">
<link rel="stylesheet" type="text/css" href="css/style-blue.css">

<style>
    .customfont{
        font-size: 30px;
        color: #23559e;
        font-weight: 300;
        line-height: 50px;
    }

    .customfont .colorchange{
        color: #fff;
    }

    @media(min-width: 300px) and (max-width: 500px){
        .customfont{
            font-size: 18px;
            color: #23559e;
            font-weight: 300;
            line-height: 28px;
            padding-bottom: 23px;
        }
    }

</style>

</head>

<body>
<div id="header-holder">
    <div class="bg-animation"></div>
    <nav id="nav" class="navbar navbar-default navbar-full">
        <div class="container-fluid">
            <div class="container container-nav">
                <div class="row">
                    <div class="col-md-12">
                        <div class="navbar-header">
                            <button aria-expanded="false" type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs">
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                            </button>
                            <a class="logo-holder" href="index.php">
                                <div class="logo"></div>
                            </a>
                        </div>
                        <div style="height: 1px;" role="main" aria-expanded="false" class="navbar-collapse collapse" id="bs">
                                <ul class="nav navbar-nav navbar-right">
                                <li><a href="index.php">Home</a></li>
                                
                                   <li class="dropdown">
                                    <a href="index.php#features">Our Services  <i class="fa fa-caret-down"></i></a>
                                    <ul class="dropdown-menu">
                                      <li><a href="infrastructuresec.php">Infrastructure Security</a></li>
                                     <li><a href="applicationsec.php">Application Security</a></li>
                                     
                                    </ul>
                                </li>
                                 <li><a href="index.php#more-features">Our Promise</a></li>
                                  <li><a href="contact.php">Contact Us</a></li>
                               
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </nav>
     <div id="top-content" class="container-fluid">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div id="main-slider">
                       
                        <div class="slide info-slide1">
                         
                            <p class="customfont"><span class="colorchange"> An Umbrella for<br></span> Information Security, Privacy and Trust.</p>
                        </div>
                       
                       
                        <div class="slide info-slide3">
                            
                            <p class="customfont">Engineering centric cyber security services that enhance security posture and optimize risks.<span class="colorchange"> Secure by Design,
                            by Default and in Deployment,</span><br> are the 3 essential principles of our overall service delivery.</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-12">
                    <div class="arrow-button-holder">
                        <a href="#features">
                            <div class="button-text">Services</div>
                            <div class="arrow-icon">
                                <i class="htfy htfy-arrow-down"></i>
                            </div>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div id="info" class="container-fluid">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
               

               <div class="info-text">INFOS3CURE’s mission is to provide top notch turn-key cyber security services - protecting businesses from cyber-attacks as an integral part of the information security lifecycle. Our engagement and collaboration using unique engineering solutions extends before and beyond project assignments as an integrated and inclusive approach.</div>

<div class="info-text">Our methodology is the result of our experience, passion and a proven combination of application of acclaimed industry standards. Our security consulting and managed security services offer a unique blend of People, Process and Technology to ensure businesses are ready to fight against cybercrime, protect information, and reduce overall risks.</div>
                
                
            </div>
        </div>
    </div>
</div>

<div id="ifeatures" class="container-fluid">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="row-title">Our Services Help</div>
            </div>
        </div>
        <div class="row">
            <div class="col-sm-6 col-md-3">
                <div class="feature-box">
                    <div class="feature-icon">
                        <img src="images/money.png" alt="">
                    </div>
                    <div class="feature-title">Manage</div>
                    <div class="feature-details">Engineering centric approach ensures consistent security measures across the information security lifecycle with high levels of reliability and trust. </div>
                </div>
            </div>
            <div class="col-sm-6 col-md-3">
                <div class="feature-box">
                    <div class="feature-icon">
                        <img src="images/analytics (1).png" alt="">
                    </div>
                    <div class="feature-title">Improve</div>
                    <div class="feature-details">Resilient and robust methodologies are an integral part of our services resulting in improved operational efficiency, repeatability and optimal security costs.</div>
                </div>
            </div>
            <div class="col-sm-6 col-md-3">
                <div class="feature-box">
                    <div class="feature-icon">
                        <img src="images/reliability.png" alt="">
                    </div>
                    <div class="feature-title">Gain</div>
                    <div class="feature-details">Trusted, reliable and inclusive approaches enable our clients to conduct their business with gained confidence.</div>
                </div>
            </div>
            <div class="col-sm-6 col-md-3">
                <div class="feature-box">
                    <div class="feature-icon">
                        <img src="images/server.png" alt="">
                    </div>
                    <div class="feature-title">Maintain</div>
                    <div class="feature-details">Partnership based service delivery ensures the highest levels of security posture and support in maintaining compliance and trust of clients. </div>
                </div>
            </div>
        </div>
    </div>
</div>


<div id="features" class="container-fluid">
<div class="bg-color"></div>
    <div class="container">
        <div class="row">
            <div class="col-xs-12">
                <div class="row-title">Security Advisory Services (SAS)</div>
            </div>
        </div>
        <div class="row rtl-cols">
            <div class="col-sm-12 col-md-6">
                <div id="features-links-holder">
                    <div class="icons-axis">
                        <img src="images/features-icon.png" alt="">
                    </div>
                  
                    <div class="feature-icon-holder feature-icon-holder2" data-id="2">
                        <div class="animation-holder"><div class="special-gradiant"></div></div>
                        <div class="feature-icon">  <img src="images/firewall (3).png" style="width: 60%;margin-top: -12px;" alt=""></div>
                        <div class="feature-title">Infrastructure Security</div>
                    </div>
                   
                    <div class="feature-icon-holder feature-icon-holder4" data-id="3">
                        <div class="animation-holder"><div class="special-gradiant"></div></div>
                        <div class="feature-icon"><img src="images/globe.png" style="width: 60%;margin-top: -12px;" alt=""></div>
                        <div class="feature-title">Application Security </div>
                    </div>
                   
                </div>
            </div>
            <div class="col-sm-12 col-md-6">
                <div id="features-holder">
                    
                    <div class="feature-box feature-d2 show-details">
                        <div class="feature-title-holder">
                           
                            <span class="feature-title">Infrastructure Security</span>
                        </div>
                        <div class="feature-details">
                            <p>Our IT infrastructure security services ensure the integrity of infrastructure by identifying application vulnerabilities, misconfigured technologies, and vulnerable components. As we identify exposures, we transfer strategic and tactical expertise to help improve your IT security posture.</p>

                            
                                          <a href="infrastructuresec.php" class="ybtn ybtn-white ybtn-shadow">Read More</a>
                            
                        </div>
                        
                    </div>
                    <div class="feature-box feature-d3">
                        <div class="feature-title-holder">
                           
                            <span class="feature-title">Application Security </span>
                        </div>
                        <div class="feature-details">
                            <p>INFOS3CURE’s Application Security services use information based on the latest application vulnerabilities, bots, suspicious URL patterns, data-type patterns and specialized heuristic detection engines, to ensure web applications remain safe from cyber threats.</p>

                           
                            <div class="buttons-holder">
                                          <a href="applicationsec.php"  class="ybtn ybtn-white ybtn-shadow">Read More</a>
                             </div>
                        </div>
                    </div>
                  

                </div>
            </div>
        </div>
    </div>
</div>


<div id="message2" class="container-fluid message-area normal-bg">
    <div class="container">
        <div class="row">
            <div class="col-sm-12 col-md-8">
                <div class="text-other-color1">Learn More about,</div>
                <div class="text-other-color2">INFOS3CURE's Cyber Security Maturity Assessment.</div>
            </div>
            <div class="col-sm-12 col-md-4">
                <div class="buttons-holder">
                    <a href="contact.php" class="ybtn ybtn-white ybtn-shadow">Contact Us</a>
                </div>
            </div>
        </div>
    </div>
</div>


<div id="more-features" class="container-fluid">
 
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="row-title">Our Promise</div>
            </div>
        </div>
        


        <div class="row">
            <div class="col-sm-6 col-md-4">
                <div class="promise">

                    <div class="promise-icon">
                        <i class="htfy htfy-tick"></i>
                    </div>
                   
                    <div class="promise-title">Security</div>
                    <div class="promise-details">We are certain of “Security” is “the state of being free from danger or threat”. Our engineers, services and technical solutions are combined to achieve the highest level of security to ensure our client’s overall security posture enhanced and information assets are protected.</div>
                </div>
            </div>
          
            

        
              <div class="col-sm-6 col-md-4">
                <div class="promise">

                    <div class="promise-icon">
                        <i class="htfy htfy-tick"></i>
                    </div>
                   
                    <div class="promise-title">Transparency</div>
                    <div class="promise-details">Collecting and handling client’s sensitive data and information is an essential part of our service. Transparency and accountability are ingrained in every step within the scope of the service.</div><br>
                </div>
            </div>
              <div class="col-sm-6 col-md-4">
                <div class="promise">

                    <div class="promise-icon">
                        <i class="htfy htfy-tick"></i>
                    </div>
                   
                    <div class="promise-title">Privacy</div>
                    <div class="promise-details">At INFOS3CURE, privacy comes first. All our processes and technologies are aligned to ensure the protection of client information during all the 7 phases of a data lifecycle.</div>
                </div>
            </div>

             
            
        </div>




    </div>
</div>



<div id="footer" class="container-fluid">
    <div class="container">
        <div class="row">
            <div class="col-md-3">
                <div class="address-holder">
                    <div class="phone"><i class="fa fa-phone"></i> <a href="tel:3174536991">(317) 453-6991</a></div>
                    <div class="email"><i class="fa fa-envelope"></i><a href="mailto:secure@INFOS3CURE"> secure@INFOS3CURE.com</a></div>
                       <div class="address">
                        <i class="fa fa-map-marker"></i> 
                        <div>26040 Acero, Suite 111<br>
                             Mission Viejo, CA <br>
                           92691, USA</div>



                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="footer-menu-holder">
                    <h4>Services</h4>
                    <ul class="footer-menu">
                        <li><a href="infrastructuresec.php">Infrastructure Security</a></li>
                        <li><a href="applicationsec.php">Application Security </a></li>
                        
                        
                    </ul>
                </div>
            </div>

            <div class="col-md-3">
                <div class="footer-menu-holder">
                    <h4>Company</h4>
                    <ul class="footer-menu">
                        <li><a href="privacypolicy.php">Privacy Policy</a></li>
                        <li><a href="termsuse.php">Terms of Use </a></li>
                        
                        
                    </ul>
                </div>
            </div>
            

            <div class="col-md-3">
                <div class="footer-menu-holder">
                    <h4>Partnerships</h4>
                    <a href="https://www.symantec.com/" target="_blank"><img src="images/secure-one-registered-partner-logo-global-registered.jpg"></a>
                   
                   
                </div>
            </div>
         </div>
           </div>
            <div class="col-xs-12"><hr>
               <div class="row">
               <div class="col-md-6 bottombar ">

                        <p>© 2018 All Rights Reserved |  <a href="http://infosharesystems.com/" target="_blank">Infoshare Systems Inc</a></p>
                        
                    </div>
                    <!--<div class="col-md-4  ">
                       
                            <div class="social-menu-holder">
                    <ul class="social-menu">
                        <li style="text-align: center;"><a href="#"><i class="fa fa-facebook"></i></a> | <a href="#"><i class="fa fa-linkedin"></i></a> | <a href="#"><i class="fa fa-twitter"></i></a></li>
                    </ul>
                </div>
                    </div>-->
                       <div class="col-md-6 bottombar">
                        <p>Powered By <a href="http://cloudmellow.com/" target="_blank">CloudMellow</a></p>
                    </div>
               </div>
            </div>
        </div>
    </div>
</div>
<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/bootstrap-slider.min.js"></script>
<script src="js/slick.min.js"></script>
<script src="js/main.js"></script>

<script type="text/javascript">
           //Contact Form
         $(function() {
           $('#signinform').submit(function(e) {
             e.preventDefault();
             console.log('Submitting');
             $.ajax({
               type: 'POST',
               url: 'php/subscription.php',
               data: new FormData($('#signinform')[0]),
               cache: false,
               contentType: false,
               processData: false,
               success: function(response) {
                 $('#get_in_touch_success2').html(response);
                  $("#signinform")[0].reset();
               }
             });
           });
         });
         </script>

</body>
</html>
