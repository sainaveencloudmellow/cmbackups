<!doctype html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0,maximum-scale=1.0, user-scalable=no">
<link rel="icon" href="images/fav.png">
<title>INFOS3CURE</title>
<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="css/bootstrap-slider.min.css">
<link rel="stylesheet" type="text/css" href="css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="css/slick.css">
<link rel="stylesheet" type="text/css" href="css/style-blue.css">
</head>

<body>

<div id="header-holder" class="inner-header color3-header web-hosting-page">
    <div class="whitebg"><img src="images/whitebg.svg" alt=""></div>
    <nav id="nav" class="navbar navbar-default navbar-full">
        <div class="container-fluid">
            <div class="container container-nav">
                <div class="row">
                    <div class="col-md-12">
                        <div class="navbar-header">
                            <button aria-expanded="false" type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs">
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                            </button>
                           <a class="logo-holder" href="index.php">
                                <div class="logo"></div>
                            </a>
                        </div>
                        <div style="height: 1px;" role="main" aria-expanded="false" class="navbar-collapse collapse" id="bs">
                                <ul class="nav navbar-nav navbar-right">
                                <li><a href="index.php">Home</a></li>
                                
                                   <li class="dropdown">
                                    <a href="index.php#features">Our Services  <i class="fa fa-caret-down"></i></a>
                                    <ul class="dropdown-menu">
                                      <li><a href="infrastructuresec.php">Infrastructure Security</a></li>
                                     <li><a href="applicationsec.php">Application Security</a></li>
                                     
                                    </ul>
                                </li>
                                 <li><a href="index.php#more-features">Our Promise</a></li>
                                  <li><a href="contact.php">Contact Us</a></li>
                               
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </nav>
    <div id="page-head" class="container-fluid inner-page">
        <div class="container">
            <div class="row">
                <div class="col-md-12 text-center">
                    <div class="page-title">INFOS3CURE Privacy Policy – Effective August 9, 2018</div>
                    <div id="page-icon">
                        <div class="pricing-icon pricing-color2">
                            <img src="images/padlock.png" style="margin-top: 10px;" alt="">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div id="h-info" class="container-fluid">
    <div class="container">
        <div class="row">
            <div class="col-md-12 policy">
                <div class="app-text">Infoshare Systems, Inc. d/b/a INFOS3CURE (“INFOS3CURE”) is sensitive to the concerns that you have about the use of the information that you disclose to INFOS3CURE via the INFOS3CURE website (the “Site”).  Accordingly, this Privacy Policy (the “Policy”) sets forth INFOS3CURE’s privacy practices and the possible uses of the information that it gathers through the Site.</div>

                <div class="privaytitle">Collection of Information</div>

                <div class="app-text">In connection with your use of the Site, INFOS3CURE may request and/or collect certain personal information from you, which may include, without limitation, your first and last name, home or business address, shipping address, phone number, email address, geographic location, geopositional data and credit or debit card number (“Your Information”).  By entering Your Information via the Site or otherwise providing Your Information to INFOS3CURE, you consent to INFOS3CURE’s use of Your Information for purposes discussed herein, as well as for purposes related to its products and services.   </div>

                <div class="app-text">INFOS3CURE will not sell, share, or rent Your Information to others in ways different from those disclosed in this Policy.  INFOS3CURE does not intend to collect information from children under 13 years of age.  If INFOS3CURE discovers that it has inadvertently collected information from a child under 13 years of age, it will promptly take all reasonable measures to delete that data from its systems. </div>

                <div class="app-text">INFOS3CURE may also collect information through the use of common information-gathering tools such as web beacons, cookies, and server logging, including, but not limited to, the date and time of your visit, your IP address, your web browser type, the pages you visit, and the website you came from.  The Site may use a technology called a “cookie.”  A cookie is a piece of information that the webserver sends to your computer (actually to your browser file) when you access the Site.  When you come back to the Site, it will detect whether you have one of the cookies on your computer.  The cookies help provide additional functionality to the Site and help INFOS3CURE analyze Site usage more accurately.  
                </div>

                <div class="privaytitle">Use of Information</div>

                      <div class="app-text">INFOS3CURE may use Your Information in order to contact you, provide its products or services you purchase and/or send you promotional and/or other marketing information about products, services and offerings. You may opt-out of receiving promotional and/or other marketing materials by following the opt-out instructions contained in the materials or by emailing INFOS3CURE at [secure@INFOS3CURE.com].</div>

                    <div class="app-text">INFOS3CURE may also use Your Information to fulfill any product or service orders and to respond to requests you may make of INFOS3CURE.  INFOS3CURE may also refer to Your Information to better understand your needs and how INFOS3CURE can improve the Site as well as its other products and services.  All users of Your Information will comply with applicable laws.</div>   

                        <div class="app-text">INFOS3CURE may enhance or merge Your Information with data obtained from third parties for the same purposes.  In addition, INFOS3CURE may aggregate information provided by you via the Site in a non-personally identifiable manner.  Such aggregated information may be disclosed to third parties for marketing purposes or for web analytics.</div>

                        <div class="app-text">Any non-personally identifiable information transferred by you in connection with your visit to the Site may be included in databases owned and maintained by INFOS3CURE or its agents.  INFOS3CURE retains all rights to these databases and the information contained in them and may use and disclose such information for marketing purposes or otherwise.</div>

              

                 <div class="privaytitle">Information Sharing</div>


                  <div class="app-text">INFOS3CURE may share Your Information with agents, contractors or partners in connection with the services that these individuals or entities perform for, or with, INFOS3CURE as part of INFOS3CURE providing its products and services.  These agents, contractors or partners are restricted from using this data in any way other than to provide services for INFOS3CURE.  INFOS3CURE may, for example, provide Your Information to agents, contractors or partners for hosting INFOS3CURE databases, for data processing services, to process payments, to deliver products that you ordered, or to send you promotional materials.</div>

 <div class="app-text">INFOS3CURE reserves the right to share Your Information in response to duly authorized information requests of governmental authorities or where required by law.  INFOS3CURE may also disclose Your Information if necessary for fraud protection and credit risk reduction purposes, or in the good-faith belief that such action is necessary to protect and defend the rights or property of INFOS3CURE or the users of the Site or to act under urgent circumstances to protect the safety of INFOS3CURE or its employees or a member of the public.</div>

 <div class="app-text">INFOS3CURE may also provide Your Information to a third party in connection with the sale, assignment, or other transfer of the business of INFOS3CURE to which the information relates, in which case INFOS3CURE will require any such buyer to agree to treat Your Information in accordance with this Policy.</div>

 <div class="app-text">INFOS3CURE may share aggregated demographic information with third party sponsors and advertisers. This aggregated demographic information is not linked to any personal information that can identify any individual person. </div>



                 <div class="privaytitle">Security</div>

                  <div class="app-text">INFOS3CURE employs commercially reasonable measures to protect Your Information. Unfortunately, no safeguards or processes can be guaranteed to be 100% secure.  Thus, we cannot ensure or warrant the security of any of Your Information.  You provide Your Information and access the Site at your own risk.</div>
                 <div class="privaytitle">External Links</div>

                  <div class="app-text"> The Site may contain links to other sites which may collect personal information about you.  In such instances, unless expressly provided to the contrary, the collection and use of your personal information will be governed by the privacy policy applicable to such external site.  Accordingly, you should review the privacy policy of such sites prior to submitting any personal information.</div>

                 <div class="privaytitle">Effective Date/Notification of Changes</div>

                  <div class="app-text">Please note that INFOS3CURE may update this Policy from time to time, and you should check this page periodically for changes.  If changes are made, INFOS3CURE will notify users by stating the date the Privacy Policy was last modified.  This Policy was last modified on August 9, 2018.</div>


                  <div class="privaytitle">Updating Your Information</div>

                   <div class="app-text">If you ever wish to access Your Information or to have Your Information deleted, updated, changed or modified, you may do so by contacting INFOS3CURE by email at [secure@INFOS3CURE.com].  </div>

                  <div class="privaytitle">Contacting INFOS3CURE </div>

                   <div class="app-text">If you have any questions about this Policy, INFOS3CURE’s privacy practices, or your dealings with INFOS3CURE, please contact INFOS3CURE by email at [secure@INFOS3CURE.com].  </div>










            </div>









        </div>
    </div>
</div>




<div id="footer" class="container-fluid">
    <div class="container">
        <div class="row">
            <div class="col-md-3">
                <div class="address-holder">
                    <div class="phone"><i class="fa fa-phone"></i> <a href="tel:3174536991">(317) 453-6991</a></div>
                    <div class="email"><i class="fa fa-envelope"></i><a href="mailto:secure@INFOS3CURE"> secure@INFOS3CURE.com</a></div>
                       <div class="address">
                        <i class="fa fa-map-marker"></i> 
                        <div>26040 Acero, Suite 111<br>
                             Mission Viejo, CA <br>
                           92691, USA</div>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="footer-menu-holder">
                    <h4>Services</h4>
                    <ul class="footer-menu">
                        <li><a href="infrastructuresec.php">Infrastructure Security</a></li>
                        <li><a href="applicationsec.php">Application Security </a></li>
                        
                        
                    </ul>
                </div>
            </div>

                <div class="col-md-3">
                <div class="footer-menu-holder">
                    <h4>Company</h4>
                    <ul class="footer-menu">
                        <li><a href="privacypolicy.php">Privacy Policy</a></li>
                        <li><a href="termsuse.php">Terms of Use </a></li>
                        
                        
                    </ul>
                </div>
            </div>
            

            <div class="col-md-3">
                <div class="footer-menu-holder">
                    <h4>Partnerships</h4>
                    <a href="https://www.symantec.com/" target="_blank"><img src="images/secure-one-registered-partner-logo-global-registered.jpg"></a>
                   
                   
                </div>
            </div>
         
           
            <div class="col-xs-12"><hr>
               <div class="row">
               <div class="col-md-6 bottombar ">

                        <p>© 2018 All Rights Reserved |  <a href="http://infosharesystems.com/" target="_blank">Infoshare Systems Inc</a></p>
                        
                    </div>
                    <!--<div class="col-md-4  ">
                       
                            <div class="social-menu-holder">
                    <ul class="social-menu">
                        <li style="text-align: center;"><a href="#"><i class="fa fa-facebook"></i></a> | <a href="#"><i class="fa fa-linkedin"></i></a> | <a href="#"><i class="fa fa-twitter"></i></a></li>
                    </ul>
                </div>
                    </div>-->
                       <div class="col-md-6 bottombar">
                        <p>Powered By <a href="http://cloudmellow.com/" target="_blank">CloudMellow</a></p>
                    </div>
               </div>
            </div>
        </div>
    </div>
</div>
<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/bootstrap-slider.min.js"></script>
<script src="js/slick.min.js"></script>
<script src="js/main.js"></script>

<script type="text/javascript">
           //Contact Form
         $(function() {
           $('#signinform').submit(function(e) {
             e.preventDefault();
             console.log('Submitting');
             $.ajax({
               type: 'POST',
               url: 'php/subscription.php',
               data: new FormData($('#signinform')[0]),
               cache: false,
               contentType: false,
               processData: false,
               success: function(response) {
                 $('#get_in_touch_success2').html(response);
                  $("#signinform")[0].reset();
               }
             });
           });
         });
         </script>

</body>
</html>
