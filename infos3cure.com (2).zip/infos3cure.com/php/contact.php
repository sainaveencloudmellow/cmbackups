<?php 
$contact_fname = $_POST['fname'];
$contact_lname = $_POST['lname'];
$contact_phone = $_POST['phone'];
$contact_email = $_POST['email'];
$contact_subject = $_POST['formsubject'];
$contact_message = $_POST['contactmessage'];








 $subject = 'Infos3cure Contact Details'; //subject of email
$to = array('sainaveen1991@gmail.com');
$message = "E-Mail Id : ".$contact_email."\r\n";
$message .= "First Name : ".$contact_fname."\r\n";
$message .= "Last Name : ".$contact_lname."\r\n";
$message .= "Phone : ".$contact_phone."\r\n";
$message .= "Subject : ".$contact_subject."\r\n";
$message .= "Message : ".$contact_message."\r\n";

$headers = "From:".$contact_email."<".$contact_email.">\r\n";

/*
if (filter_var($contact_email, FILTER_VALIDATE_EMAIL)) { 
	mail(implode(',', $to), $subject, $message, $headers); 
	$message = "We Appreciate Your Intrest. We’ll Get Back To You Soon!";
}else{
	$message = "Invalid Email ID, Please Provide An Correct Email ID.";
}
*/


function post_captcha($user_response) 
    {
        $fields_string = '';
        $fields = array(
            'secret' => '6LdgOmkUAAAAAEuFDEfKeDtOS8LRdXadS3Od9Pte',
            'response' => $user_response
        );
        foreach($fields as $key=>$value)
        $fields_string .= $key . '=' . $value . '&';
        $fields_string = rtrim($fields_string, '&');

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, 'https://www.google.com/recaptcha/api/siteverify');
        curl_setopt($ch, CURLOPT_POST, count($fields));
        curl_setopt($ch, CURLOPT_POSTFIELDS, $fields_string);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, True);

        $result = curl_exec($ch);
        curl_close($ch);

        return json_decode($result, true);
    }

    // Call the function post_captcha
    $res = post_captcha($_POST['g-recaptcha-response']);

    if (!$res['success']) {
        // What happens when the CAPTCHA wasn't checked
        echo '<p>Please make sure you check the security CAPTCHA box.</p><br>';
    } else {
        // If CAPTCHA is successfully completed...

        mail(implode(',', $to), $subject, $message, $headers); 

        $message = "We Appreciate Your Intrest. We’ll Get Back To You Soon!";
     	echo $message ;
    }


?>