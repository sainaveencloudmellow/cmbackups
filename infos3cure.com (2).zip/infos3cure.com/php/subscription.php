<?php 

$contact_email = $_POST['subscriberemail'];








 $subject = 'Infos3cure Subscription Details'; //subject of email
$to = array('pinky929.929@gmail.com,secure@infos3cure.com,infos3cure@gmail.com');
$message = "E-Mail Id : ".$contact_email."\r\n";

$headers = "From:".$contact_email."<".$contact_email.">\r\n";

if (filter_var($contact_email, FILTER_VALIDATE_EMAIL)) { // this line checks that we have a valid email address
	mail(implode(',', $to), $subject, $message, $headers); //This method sends the mail.
	$message = "We Appreciate Your Intrest. We’ll Get Back To You Soon!";
}else{
	$message = "Invalid Email ID, Please Provide An Correct Email ID.";
}

echo $message ;
?>