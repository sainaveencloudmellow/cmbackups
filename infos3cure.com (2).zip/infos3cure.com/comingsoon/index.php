<!DOCTYPE html>

<html>
<head>
	
	<meta charset="utf-8" />
	
	<title>Coming Soon</title>
	<link rel="stylesheet" href="css/flexi-background.css" type="text/css" media="screen" />
	<link rel="stylesheet" href="css/ml-coming-soon.css" type="text/css" media="screen" />
	<link rel="stylesheet" href="webfonts/stylesheet.css" type="text/css" media="screen" />
	<link href='https://fonts.googleapis.com/css?family=Open+Sans:400,300,600' rel='stylesheet' type='text/css'>
	
	
	<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>
	<script type="text/javascript">
	// MediaLoot jQuery Countdown Timer
	// Description: Allows you to choose which unit of time from which to countdown and allows you to style each unit of time separately.
	// Author: Natalie Hipp | MediaLoot.com
	// URL: http://medialoot.com/item/
	
	$(document).ready(function() {
			
		function mlCountdown() {
		// Step 1: Make sure to call jQuery in your <head>
		// Step 2: Fill in the following two variables
			var eventTime =   '1533231000'; //'1533081639'; // Unix Event Time - Get your stamp from http://www.unixtimestamp.com/index.php
		
		
	//	var eventTime = parseInt((new Date('2018.07.10').getTime() / 1000).toFixed(0))
		var startFrom = 'D'; // Adjust from which time unit you'd like to countdown: Use D for days, H for hours, M for minutes, or S for seconds.
			
		// Step 3: Add some spans in your HTML
		/* Each Unit of time is displayed independently so that you can style them differently. 
		
		Create <span>'s for each unit of time. Each span must have the class "ml-countdown" and then add the appropriate following classes for what you'd like to display: "days", "hours", "minutes", & "seconds". 
		
		For example, to display the number of days remaining, add this: <span class="ml-countdown days"></span>
		*/
			
		// We'll take it from here
			var currentTime = Math.round(new Date().getTime() / 1000); // Grabs current time in seconds
			var timeLeft = eventTime - currentTime;		
			 
			// Calculate numbers based on what kind of time they want to count from
			if (startFrom == 'S') {
						var scLeftTemp = Math.floor(timeLeft);
						if(scLeftTemp <= 0){
							var scLeft = "0" + scLeftTemp.toString();
						}
						else {
							var scLeft =  scLeftTemp;
						}
				
				$(".ml-countdown.seconds").html(scLeft);
			}
			else if (startFrom == 'M') {
				var minLeftTemp = Math.floor(timeLeft / 60);
				if(minLeftTemp <= 9){
					minLeft = "0" + minLeftTemp.toString();
				}else{
					minLeft = minLeftTemp;	
				}

				var scLeft1 = timeLeft - (minLeft * 60); // number of whole minutes
				var scLeftTemp = Math.floor(scLeft1);
				if(scLeftTemp <= 9){
					scLeft = "0" + scLeftTemp.toString();
				}else {
					scLeft = scLeftTemp;
				}
				
				$(".ml-countdown.minutes").html(minLeft);
				$(".ml-countdown.seconds").html(scLeft);
			}
			else if (startFrom == 'H') {
				
				var hrLeftTemp = Math.floor(timeLeft / 60 / 60);
				
				if(hrLeftTemp <= 9)
				{
				var hrLeft = "0" + hrLeftTemp.toString();
				}
				else {
					var hrLeft =hrLeftTemp;
				
				}
				var minLeft1 = hrLeft * 60 * 60; // number of whole hours
				var minLeft2 = timeLeft - minLeft1;
				var minLeftTemp = Math.floor(minLeft2 / 60);
				if(minLeftTemp <= 9){
					var minLeft = "0" + minLeftTemp.toString();
				}
				else{var minLeft = minLeftTemp}
				var scLeft1 = minLeft * 60; //number of whole minutes
				var scLeft2 = timeLeft - minLeft1 - scLeft1;
				var scLeftTemp = Math.floor(scLeft2);
				if(scLeftTemp <= 9 ){
					scLeft = "0" + scLeftTemp.toString();
				}
				else{
					scLeft = scLeftTemp;
				}
				
				$(".ml-countdown.hours").html(hrLeft);
				$(".ml-countdown.minutes").html(minLeft);
				$(".ml-countdown.seconds").html(scLeft);
			}
			// Otherwise, default as if counting from days
			else {
				var dayLeftTemp = Math.floor(timeLeft / 60 / 60 / 24);
				if(dayLeftTemp <= 9)
{				var dayLeft = "0" + dayLeftTemp.toString(); }
                else { var dayLeft = dayLeftTemp; }
				var hrLeft1 = dayLeft * 24 * 60 * 60; // days left in seconds
				var hrLeft2 = timeLeft - hrLeft1;
				var hrLeftTemp = Math.floor(hrLeft2 / 60 / 60);
				if(hrLeftTemp <= 9){var hrLeft = "0" + hrLeftTemp.toString()}
				else{
					var hrLeft = hrLeftTemp;
				}
				var minLeft1 = hrLeft * 60 * 60; // hours left in seconds
				var minLeft2 = timeLeft - hrLeft1 - minLeft1;

				var minLeftTemp = Math.floor(minLeft2 / 60);
				if(minLeftTemp <= 9){
					var minLeft = "0" + minLeftTemp.toString();
				}
				else{var minLeft = minLeftTemp}
				
				var scLeft1 = minLeft * 60; // minutes left in seconds
				var scLeft2 = timeLeft - hrLeft1 - minLeft1 - scLeft1;
				var scLeftTemp = Math.floor(scLeft2);
				if(scLeftTemp <= 9 ){
					scLeft = "0" + scLeftTemp.toString();
				}
				else{
					scLeft = scLeftTemp;
				}
				
				
				$(".ml-countdown.days").html(dayLeft);
				$(".ml-countdown.hours").html(hrLeft);
				$(".ml-countdown.minutes").html(minLeft);
				$(".ml-countdown.seconds").html(scLeft);
			}
		}
		
		window.onload=mlCountdown;
		window.setInterval( mlCountdown, 1000);
			
	});
	</script>
			
</head>
<body>
	<script src="js/flexi-background.js" type="text/javascript" charset="utf-8"></script>

	<div class="noise">
		
		<div class="content">
			<h1><span>Something Awesome is in the works</span></h1>
			<p>We are working on a new and exciting service / product that we think you’ll really like!<br>
			Enter your email address below to be the first to know when we launch it.</p>
			<ul>
				<li><span class="ml-countdown days"></span>Days</li>
				<li><span class="ml-countdown hours"></span>Hours</li>
				<li><span class="ml-countdown minutes"></span>Minutes</li>
				<li><span class="ml-countdown seconds"></span>Seconds</li>
			</ul>
			<form role="form" id="contact_send" method="post">
				<input type="text" onclick="this.value='';" onfocus="this.select()" onblur="this.value=!this.value?'Email Address':this.value;" value="Email Address" name="email" />
				<input type="submit" value="Sign Up" />
			</form> 
			<div style="text-align: center;" id="get_in_touch_success" class="alert-success"></div>
		</div>
		
		
	
	</div>
			

<script type="text/javascript">
		   //Contact Form
		 $(function() {
		   $('#contact_send').submit(function(e) {
		     e.preventDefault();
		     console.log('Submitting');
		     $.ajax({
		       type: 'POST',
		       url: 'php/mailtest/index.php',
		       data: new FormData($('#contact_send')[0]),
		       cache: false,
		       contentType: false,
		       processData: false,
		       success: function(response) {
		         $('#get_in_touch_success').html(response);
		          $("#contact_send")[0].reset();
		       }
		     });
		   });
		 });
		 </script>



</body>
</html>