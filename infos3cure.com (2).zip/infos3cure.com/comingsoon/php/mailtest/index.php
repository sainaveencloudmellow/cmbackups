<?php

require("class.phpmailer.php");

$contact_email = $_POST['email'];
$testvar = "Vikas";
$message = "We Appreciate Your Intrest. We’ll Get Back To You Soon!";

$mail = new PHPMailer();

$mail->IsSMTP();
$mail->Host = "infos3cure.com";
$mail->SMTPAuth = true;
//$mail->SMTPSecure = "ssl";
$mail->Port = 587;
$mail->Username = "test@infos3cure.com";
$mail->Password = "b[)bR@,f6mpX";

$mail->From = "test@infos3cure.com";
$mail->FromName = "InfoSecure";
$mail->AddAddress("vikaskambhampati@gmail.com");
$mail->AddCC("pinky929.929@gmail.com");
//$mail->AddReplyTo("mail@mail.com");

$mail->IsHTML(true);

$mail->Subject = "InfoSecure Subscription Details";
$mail->Body = $contact_email;
// If we want to send to variable data this is used $mail->Body = $testvar.$contact_email;

//$mail->AltBody = "This is the body in plain text for non-HTML mail clients";

if(!$mail->Send())
{
echo "Message could not be sent. <p>";
echo "Mailer Error: " . $mail->ErrorInfo;
exit;
}

echo $message;

?>