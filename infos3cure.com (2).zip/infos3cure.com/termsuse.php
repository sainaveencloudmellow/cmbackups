<!doctype html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0,maximum-scale=1.0, user-scalable=no">
<link rel="icon" href="images/fav.png">
<title>INFOS3CURE</title>
<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="css/bootstrap-slider.min.css">
<link rel="stylesheet" type="text/css" href="css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="css/slick.css">
<link rel="stylesheet" type="text/css" href="css/style-blue.css">
</head>

<body>

<div id="header-holder" class="inner-header color3-header web-hosting-page">
    <div class="whitebg"><img src="images/whitebg.svg" alt=""></div>
    <nav id="nav" class="navbar navbar-default navbar-full">
        <div class="container-fluid">
            <div class="container container-nav">
                <div class="row">
                    <div class="col-md-12">
                        <div class="navbar-header">
                            <button aria-expanded="false" type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs">
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                            </button>
                           <a class="logo-holder" href="index.php">
                                <div class="logo"></div>
                            </a>
                        </div>
                        <div style="height: 1px;" role="main" aria-expanded="false" class="navbar-collapse collapse" id="bs">
                                 <ul class="nav navbar-nav navbar-right">
                                <li><a href="index.php">Home</a></li>
                                
                                   <li class="dropdown">
                                    <a href="index.php#features">Our Services  <i class="fa fa-caret-down"></i></a>
                                    <ul class="dropdown-menu">
                                      <li><a href="infrastructuresec.php">Infrastructure Security</a></li>
                                     <li><a href="applicationsec.php">Application Security</a></li>
                                     
                                    </ul>
                                </li>
                                 <li><a href="index.php#more-features">Our Promise</a></li>
                                  <li><a href="contact.php">Contact Us</a></li>
                               
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </nav>
    <div id="page-head" class="container-fluid inner-page">
        <div class="container">
            <div class="row">
                <div class="col-md-12 text-center">
                    <div class="page-title">INFOS3CURE TERMS OF USE – Effective August 9, 2018</div>
                    <div id="page-icon">
                        <div class="pricing-icon pricing-color2">
                            <img src="images/padlock.png" style="margin-top: 10px;" alt="">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div id="h-info" class="container-fluid">
    <div class="container">
        <div class="row">
            <div class="col-md-12 policy">
                <div class="app-text">Please read the following INFOS3CURE Terms of Use (“Terms”) carefully. They govern your use of the Infoshare Systems, Inc. d/b/a INFOS3CURE (“INFOS3CURE”) website (the “Site”).  By accessing and using the Site, you acknowledge that you have read and understood all of the Terms, and you agree to be bound by these Terms.  If you do not agree to these Terms, please do not access or use the Site. </div>
                <div class="app-text"> 
INFOS3CURE reserves the right to change the Terms under which the Site is offered in its sole and absolute discretion at any time without notice.  Any such changes will be posted on the Site.  It is your responsibility to review these Terms for any changes each time that you access or use the Site.  All changes to the Terms are effective from the date posted.  If you do not agree to the amended Terms, you must stop accessing or using the Site.  You will be deemed to have accepted the amended Terms if you continue to access or use the Site after such amended terms are posted on the Site.
</div>

                <div class="privaytitle">Description of the Site</div>

                <div class="app-text">The Site enables users to review information regarding INFOS3CURE and its offered products and services.  Users of the Site are hereinafter referred to as “Users”.          
                </div>

                <div class="privaytitle">Registration for the Site</div>

                      <div class="app-text">In order to access and use certain pages of the Site, you may be required to set up a User account (“Your Account”).  In setting up and maintaining Your Account, you agree to provide accurate information regarding your identity, your age (in order to use the Site, Users must be at least 18 years of age), your contact information, and any other information requested by INFOS3CURE related to the Site including, but not limited to, your billing and credit/debit card information. You will set your own password for accessing the Site and shall be solely and strictly liable for everything that occurs through the use of Your Account.  You are responsible for maintaining the confidentiality of your password and for restricting access to your computer and mobile device, and you agree to accept responsibility for all activities that occur under Your Account or password.  You are prohibited from selling, trading or otherwise transferring Your Account to another party or charging anyone for access to any portion of the Site.  You agree to immediately notify INFOS3CURE of any unauthorized use of your password or Your Account, or any other breach of security of which you become aware.</div>

                    <div class="app-text">By setting up Your Account and using those pages of the Site, you represent and warrant that (a) you have not previously been suspended or removed from the Site; (b) are not a direct competitor of INFOS3CURE; (c) that you have full power and authority to agree to these Terms; and (d) that you expressly agree that you will receive communications from INFOS3CURE, including email messages and/or text messages.  You acknowledge and agree that you consent to the receipt of such messages and that your receipt of such messages does not violate the CAN-SPAM Act and/or any state and federal laws related to Do-Not-Call registries.  You may stop receiving such messages by following the opt-out instructions provided by INFOS3CURE in any such communication.</div>   

                        <div class="app-text">INFOS3CURE transmits all payment information using SSL encryption and complies with DCL data security standards.  Any questions can and should be addressed to: [secure@INFOS3CURE.com].  </div>

              

                 <div class="privaytitle">Authorized Use of the Site</div>


                  <div class="app-text">You may access and use the Site only for legal and appropriate uses.  INFOS3CURE reserves the right to make changes to the Site at any time without prior notice.  Your access to and use of the Site is completely at the discretion of INFOS3CURE, and your access to and use of the Site may be blocked, suspended, or terminated without prior notice at any time for any reason or for no reason, including, without limitation, for any violation of the below rules whether done by you or by others with your encouragement.  In such event, you agree that INFOS3CURE shall not be liable for any alleged loss/harm resulting from INFOS3CURE’s actions.</div>

                    <ul>
                        <li>You must comply with all state, federal, and/or international laws, rules, policies and/or licenses governing communications while using the Site.</li>
                        <li>You may not impersonate any other persons or otherwise misrepresent your identity or your affiliation with any person, group or entity when using the Site.</li>
                         <li>You may not use the Site for your own commercial purposes</li>
                          <li> You may not interfere or attempt to interfere with the Site or another User’s use of the Site by use of any program, script, command, device, software, routine, or otherwise. </li>
<li> You may not attempt to gain unauthorized access to any page or section of the Site by hacking, password “mining”, violating security measures or through any other illegitimate or illegal means.</li>
<li> You may not embed any page of the Site in “frames” running from other websites.</li>
<li> You may not mirror the Site on any other website or server.</li>
<li> You may not remove any copyright, trademark or other proprietary rights notices contained in or on the Site or violate the intellectual property or contractual rights of INFOS3CURE or any other third parties.</li>
<li>  You may not transmit any worms, Trojan Horses, viruses, defects, or any items of a destructive nature or submit any unsolicited advertising such as SPAM.</li>
<li> You may not use automated means (such as harvesting bots, robots, spiders, or scrapers) to access the Site.</li>
<li> You may not submit anything that is illegal, profane, baleful, indecent, pornographic or abusive to and/or through the Site.  </li>


                <div class="app-text">By using the Site, you are acknowledging your understanding that INFOS3CURE has the right to make changes to any content on the Site including, but not limited to, data, brands, text, images, software, video, and materials without prior notice to you. </div>   
                <div class="app-text">If INFOS3CURE receives reports of any violation of the above rules, specifically, or these Terms, generally, INFOS3CURE may at is discretion investigate the same and take any action it deems appropriate including reporting to and cooperating with relevant law enforcement agencies. </div>


                    </ul>



                 <div class="privaytitle">License and User Information</div>

                  <div class="app-text">INFOS3CURE grants you a limited, non-exclusive, non-transferable license to access and use the Site in legally authorized jurisdictions for legal purposes.  However, you may not download or modify the Site, or any portion of the Site, except with express written consent of INFOS3CURE.  The Site may not be reproduced, duplicated, copied, sold, resold, visited, or otherwise exploited for any commercial purpose without express written consent of INFOS3CURE.  Any unauthorized use of the Site shall automatically terminate the license granted to you by INFOS3CURE for such use. </div>
                <div class="app-text">You shall be solely responsible for your actions and the contents of your transmissions to the Site. Although INFOS3CURE does not claim ownership of any of the information that you submit via the Site, by submitting information via the Site, you automatically grant INFOS3CURE an irrevocable, perpetual, non-exclusive, fully paid, worldwide license to use, copy, perform, display, reproduce and distribute that information on or in connection with the Site.  Further, by submitting any information to INFOS3CURE, you represent and warrant that you have the legal right to do so and that such submission is accurate, complete, current, and is not in violation of any contractual restrictions or other third party rights.</div>

                 <div class="privaytitle">Intellectual Property</div>

                  <div class="app-text">You acknowledge and agree that the Site, all patent rights, trade secret rights, design rights, copyrights, trademark rights, and other property rights in the Site shall at all times remain the sole property of INFOS3CURE. You will not acquire any right, title or interest in or to the Site by reason of these Terms, except for the non-exclusive license to use the Site in accordance with these Terms.</div>
   <div class="app-text">Except as otherwise noted herein or otherwise on the Site, all information, documentation, and other content posted on the Site is the property of INFOS3CURE, its affiliates, and/or its licensors. The graphics, icons, and overall appearance of the Site is the property of INFOS3CURE. The posting of information, documentation, and other content does not constitute a waiver of any of INFOS3CURE’s, an affiliate’s, and/or a third party licensor’s proprietary rights in such information, documentation, and other content (such as, but not limited to, copyrights or trademarks) or a transfer of any such rights to you or any third party.  The information, documentation, and other content posted on the Site is protected by U.S. and international copyright laws, both as individual works and as collections. You agree not to delete any copyright or similar notice from any information, documentation, and other content you obtain from the Site.  You may not sell, republish, frame in another webpage, or use on another website, any of the information, documentation, and other content, or any portion thereof, posted in or on the Site without the prior written consent of INFOS3CURE.  You may view, print, copy, and download portions of the information, documentation, and other content of the Site solely in connection with your use of the Site, and solely for your own individual, internal use or records.  INFOS3CURE and its affiliates reserve the right to revoke this authorization at any time.</div>
   <div class="app-text">To be clear, you accept and acknowledge that, as between INFOS3CURE and you, any and all intellectual property rights (including but not limited to patent, copyright, trademark) as well as any other proprietary rights (e.g., trade secrets) in and to the Site are owned exclusively by INFOS3CURE.  
</div>


                  <div class="privaytitle">Dealings with Third Parties and Links</div>

                   <div class="app-text">The Site may contain links to other third party external sites.  The links are provided “as is.”  You should be aware that you use them at your own risk.  Your participation, communication or business dealings with any third party found on or through the Site, regarding the payment and delivery of the related products or services, or any other terms, conditions, warranties or representations associated with such dealings, are solely between you and such third party.  INFOS3CURE does not endorse, and is not liable for, any content, products, site, software or other materials available on such other sites, even if a page or pages of the other sites are framed within a page of the Site.  INFOS3CURE is not responsible for the privacy practices or the content of other sites.  For your protection, please refer to the terms of service/use and privacy policies of the respective sites.  You acknowledge, understand and agree that INFOS3CURE shall not be responsible or liable, directly or indirectly, for any damage or loss caused or alleged to be caused by or in connection with use of or reliance on any such content, goods or site available on such other sites.  INFOS3CURE shall not be liable for any errors or delays in the content, goods or site available on such other sites, or for any actions taken or not taken in reliance thereon. </div>

                  <div class="privaytitle">Disclaimer </div>

                   <div class="app-text">TO THE EXTENT PERMITTED BY APPLICABLE LAW, THE SITE IS PROVIDED ON AN “AS IS” “AS AVAILABLE” AND “WITH ALL FAULTS” BASIS AND WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESS OR IMPLIED.  INFOS3CURE DOES NOT GUARANTEE, REPRESENT, OR WARRANT THAT YOUR USE OF THE SITE WILL BE UNINTERRUPTED, ERROR FREE, OR VIRUS FREE, OR THAT THE SITE WILL MEET YOUR REQUIREMENTS OR EXPECTATIONS OR BE SAFE.  INFORMATION OBTAINED THROUGH THE SITE HAS NOT BEEN VERIFIED, AND INFOS3CURE DOES NOT GUARANTEE, REPRESENT, OR WARRANT THAT SUCH INFORMATION IS USEFUL, SUITABLE, ACCURATE, COMPLETE, RELIABLE, OR OTHERWISE VALID. </div> 
                    <div class="app-text">INFOS3CURE DISCLAIMS ALL WARRANTIES, EXPRESS OR IMPLIED, INCLUDING, BUT NOT LIMITED TO ANY WARRANTY OF TITLE, NON-INFRINGEMENT, MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, OR ANY WARRANTY ARISING FROM A COURSE OF DEALING, TRADE USAGE, OR TRADE PRACTICE.</div>
                    <div class="app-text">INFOS3CURE MAKES NO WARRANTY OR REPRESENATION THAT THE SITE WILL BE UNINTERRUPTED, TIMELY, SECURE, OR ERROR-FREE.  FURTHER, INFOS3CURE MAKES NO WARRANTY OR REPRESENATION THAT THE SITE WILL MEET YOUR REQUIREMENTS OR EXPECTATIONS OR THAT ANY IDENTIFIED ERRORS WILL BE CORRECTED.  IN PARTICULAR, OPERATION OF THE SITE MAY BE MOMENTARILY INTERRUPTED DUE TO SITE MAINTENTANCE, UPDATES, OR TECHNICAL IMPROVEMENTS AND/OR DUE TO TERRORISM, NATURAL DISASTERS AND/OR ACTS OF GOD.  INFOS3CURE DISCLAIMS ALL LIABILTY FOR DAMAGES CAUSED BY ANY SUCH INTERRUPTION.</div>
                    <div class="app-text">YOU ASSUME ALL RISK FOR ANY DAMAGE TO YOUR COMPUTER OR MOBILE PHONE OR LOSS OF DATA THAT RESULTS FROM OBTAINING ANY CONTENT FROM THE SITE, INCLUDING ANY DAMAGES RESULTING FROM COMPUTER VIRUSES.  
                                </div>
                      <div class="privaytitle">Limitation of Liability </div>

                     <div class="app-text"> YOU ACKNOWLEDGE THAT YOU ARE 18 YEARS OF AGE, OR OLDER.  YOU ACKNOWLEDGE AND AGREE THAT USE OF THE SITE IS AT YOUR SOLE RISK.  NEITHER INFOS3CURE, NOR ANY OF INFOS3CURE’S DIRECTORS, OFFICERS, EMPLOYEES, AFFILIATES, AGENTS, ATTORNEYS, REPRESENTATIVES, OR LICENSORS (COLLECTIVELY, “INFOS3CURE ASSOCIATES”) SHALL BE LIABLE TO YOU OR ANY THIRD PARTY FOR ANY COMPENSATORY, DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, PUNITIVE, OR CONSEQUENTIAL DAMAGES, OR ATTORNEYS’ FEES, OR FOR LOST DATA OR LOST PROFIT, ARISING OUT OF YOUR USE OF THE SITE OR INABILITY TO GAIN ACCESS TO OR USE THE SITE OR OUT OF ANY BREACH OF ANY WARRANTY, EVEN IF INFOS3CURE OR A INFOS3CURE ASSOCIATE HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES OR SUCH DAMAGES WERE FORESEEABLE.</div>

<div class="app-text">IN NO EVENT WILL INFOS3CURE OR ANY INFOS3CURE ASSOCIATES BE LIABLE TO YOU FOR CLAIMS THAT RESULT FROM YOUR RELIANCE ON ANY INFORMATION THAT YOU OBTAIN THROUGH YOUR USE OF THE SITE.  
YOUR SOLE RIGHT AND REMEDY WITH RESPECT TO ANY DISPUTE WITH INFOS3CURE IS TO STOP USING THE SITE. </div>

<div class="app-text">
 BECAUSE SOME STATES OR JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF LIABILITY FOR CONSEQUENTIAL, INCIDENTAL OR SPECIAL DAMAGES, IN SUCH STATES AND JURISDICTIONS, LIABILITY IS LIMITED TO THE GREATEST EXTENT PERMITTED BY LAW.  IF THE FOREGOING LIMITATIONS ARE UNENFORCEABLE, YOU AGREE THAT INFOS3CURE’S LIABILITY TO YOU UNDER THESE TERMS SHALL NOT EXCEED ANY AMOUNTS PAID BY YOU TO INFOS3CURE IN THE THREE (3) MONTHS PRIOR TO THE ACCRUAL OF ANY SUCH CLAIM.  </div>

 <div class="app-text">
THE SITE IS PROVIDED BY INFOS3CURE FROM ITS OFFICES WITHIN THE UNITED STATES.  INFOS3CURE MAKES NO WARRANTY OR REPRESENTATION THAT MATERIAL AVAILABLE THROUGH THE SITE IS LEGAL, APPROPRIATE, OR AVAILABLE FOR USE OUTSIDE THE UNITED STATES.  IF YOU USE THE SITE FROM A LOCATION OUTSIDE THE UNITED STATES, YOU ARE RESPONSIBLE FOR COMPLIANCE WITH ALL APPLICABLE LAWS, AND INFOS3CURE ACCEPTS NO RESPONSIBILITY FOR SUCH USE.</div>
<div class="app-text">
YOU ACKNOWLEDGE AND AGREE THAT ANY AND ALL DISCLAIMERS IN THESE TERMS AND THE PROVISIONS OF THESE TERMS REFLECT A FAIR AND REASONABLE ALLOCATION OF RISK BETWEEN INFOS3CURE AND YOU.</div>

 <div class="privaytitle">Indemnification </div>

<div class="app-text">YOU WILL INDEMNIFY AND HOLD INFOS3CURE AND ANY INFOS3CURE ASSOCIATES HARMLESS WITH RESPECT TO ANY SUITS OR CLAIMS ARISING OUT OF OR RELATING TO: (A) YOUR BREACH OF THESE TERMS; AND/OR (B) YOUR USE OF THE SITE.</div>


<div class="privaytitle">Privacy Policy </div>
<div class="app-text">INFOS3CURE respects and is committed to your privacy.  Please review INFOS3CURE’s Privacy Policy [INSERT LINK TO PRIVACY POLICY], which also governs your visit to the Site, to understand INFOS3CURE’s privacy practices.  If you agree with the Privacy Policy you may continue with the Site.  However, if you do not agree with the Privacy Policy, you are not authorized to access or use the Site and must discontinue use.</div>

<div class="privaytitle">DMCA Policy </div>

<div class="app-text">INFOS3CURE respects the intellectual property rights of others.  If you believe that any content posted on the Site infringes any copyrights that you own, please contact INFOS3CURE immediately by emailing it at the email address below in the Notices section.      </div>


<div class="privaytitle">Notices </div>

<div class="app-text">Where required, INFOS3CURE may give notice to you by a general posting on the Site, by electronic mail, or by conventional mail to your address of record. You may give notice to INFOS3CURE by electronic mail or by conventional mail to the address below. If you have any questions about these Terms, the practices of the Site, or your dealings with INFOS3CURE, please email INFOS3CUREn at [secure@INFOS3CURE.com].</div>



<div class="privaytitle">Law, Jurisdiction and Venue</div>

<div class="app-text">These Terms and your access to and use of the Site are governed by, interpreted, construed, and enforced in accordance with the laws of the State of Indiana, without reference to its conflict of law provisions. All disputes arising out of or related to these Terms shall be exclusively brought and exclusively maintained in the courts of competent jurisdiction situated in Marion County, Indiana. You hereby consent to and waive any objection to the exclusive personal jurisdiction and venue of such courts.</div>



<div class="privaytitle">Miscellaneous</div>

<div class="app-text">You acknowledge and agree that the provisions, disclosures and disclaimers set forth in these Terms are fair and reasonable and your agreement to follow and be bound by them is not the result of fraud, duress or undue influence exercised upon you by any person or entity.  The failure of INFOS3CURE to exercise or enforce any right or provision of these Terms shall not constitute a waiver of such right or provision.  If any provision of these Terms is found by a court of competent jurisdiction to be invalid, the parties nevertheless agree that the court should endeavor to give effect to the parties’ intentions as reflected in the provision, and the other provisions of the Terms shall remain in full force and effect. </div>
<div class="app-text">INFOS3CURE shall have the right to assign these Terms and to sublicense any and all of its rights under these Terms.  These Terms, including any documents referenced herein and any additional operating rules or policies as posted on the Site (such as the Privacy Policy), represent the entire understanding between you and INFOS3CURE regarding your use of the Site. These Terms (and the Privacy Policy) supersede all previous written or oral agreements between you and INFOS3CURE with respect to such subject matter.  Notwithstanding any provision of these Terms, INFOS3CURE has available all remedies at law or equity to enforce these Terms.
 </div>




            </div>









        </div>
    </div>
</div>


<div id="footer" class="container-fluid">
    <div class="container">
        <div class="row">
            <div class="col-md-3">
                <div class="address-holder">
                    <div class="phone"><i class="fa fa-phone"></i> <a href="tel:3174536991">(317) 453-6991</a></div>
                    <div class="email"><i class="fa fa-envelope"></i><a href="mailto:secure@INFOS3CURE"> secure@INFOS3CURE.com</a></div>
                       <div class="address">
                        <i class="fa fa-map-marker"></i> 
                        <div>26040 Acero, Suite 111<br>
                             Mission Viejo, CA <br>
                           92691, USA</div>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="footer-menu-holder">
                    <h4>Services</h4>
                    <ul class="footer-menu">
                        <li><a href="infrastructuresec.php">Infrastructure Security</a></li>
                        <li><a href="applicationsec.php">Application Security </a></li>
                        
                        
                    </ul>
                </div>
            </div>

                <div class="col-md-3">
                <div class="footer-menu-holder">
                    <h4>Company</h4>
                    <ul class="footer-menu">
                        <li><a href="privacypolicy.php">Privacy Policy</a></li>
                        <li><a href="termsuse.php">Terms of Use </a></li>
                        
                        
                    </ul>
                </div>
            </div>
            

            <div class="col-md-3">
                <div class="footer-menu-holder">
                    <h4>Partnerships</h4>
                    <a href="https://www.symantec.com/" target="_blank"><img src="images/secure-one-registered-partner-logo-global-registered.jpg"></a>
                   
                   
                </div>
            </div>
         
           
            <div class="col-xs-12"><hr>
               <div class="row">
               <div class="col-md-6 bottombar ">

                        <p>© 2018 All Rights Reserved |  <a href="http://infosharesystems.com/" target="_blank">Infoshare Systems Inc</a></p>
                        
                    </div>
                    <!--<div class="col-md-4  ">
                       
                            <div class="social-menu-holder">
                    <ul class="social-menu">
                        <li style="text-align: center;"><a href="#"><i class="fa fa-facebook"></i></a> | <a href="#"><i class="fa fa-linkedin"></i></a> | <a href="#"><i class="fa fa-twitter"></i></a></li>
                    </ul>
                </div>
                    </div>-->
                       <div class="col-md-6 bottombar">
                        <p>Powered By <a href="http://cloudmellow.com/" target="_blank">CloudMellow</a></p>
                    </div>
               </div>
            </div>
        </div>
    </div>
</div>
<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/bootstrap-slider.min.js"></script>
<script src="js/slick.min.js"></script>
<script src="js/main.js"></script>

<script type="text/javascript">
           //Contact Form
         $(function() {
           $('#signinform').submit(function(e) {
             e.preventDefault();
             console.log('Submitting');
             $.ajax({
               type: 'POST',
               url: 'php/subscription.php',
               data: new FormData($('#signinform')[0]),
               cache: false,
               contentType: false,
               processData: false,
               success: function(response) {
                 $('#get_in_touch_success2').html(response);
                  $("#signinform")[0].reset();
               }
             });
           });
         });
         </script>

</body>
</html>
