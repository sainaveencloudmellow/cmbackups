<?php

require("class.phpmailer.php");

$contact_fname = $_POST['fname'];
$contact_lname = $_POST['lname'];
$contact_phone = $_POST['phone'];
$contact_email = $_POST['email'];
$contact_subject = $_POST['formsubject'];
$contact_message = $_POST['contactmessage'];
$subject = 'Infos3cure Contact Details'; //subject of email

$message = "E-Mail Id : ".$contact_email."\r\n<br>";
$message .= "First Name : ".$contact_fname."\r\n<br>";
$message .= "Last Name : ".$contact_lname."\r\n<br>";
$message .= "Phone : ".$contact_phone."\r\n<br>";
$message .= "Subject : ".$contact_subject."\r\n<br>";
$message .= "Message : ".$contact_message."\r\n<br>";

$mail = new PHPMailer();

$mail->IsSMTP();
$mail->Host = "infos3cure.com";  /*SMTP server*/

$mail->SMTPAuth = true;
//$mail->SMTPSecure = "ssl";
$mail->Port = 587;
$mail->Username = "test@infos3cure.com";  /*Username*/
$mail->Password = "{pIOK;5rs@H@";    /**Password**/

$mail->From = "test@infos3cure.com";/*From address required*/
$mail->FromName = "Infos3cure";

$mail->AddAddress("secure@infos3cure.com");
$mail->AddCC("infos3cure@gmail.com");
//$mail->AddReplyTo("mail@mail.com");

$mail->IsHTML(true);

$mail->Subject = $subject;
$mail->Body = $message;
//$mail->AltBody = "This is the body in plain text for non-HTML mail clients";

function post_captcha($user_response) 
    {
        $fields_string = '';
        $fields = array(
            'secret' => '6LdgOmkUAAAAAEuFDEfKeDtOS8LRdXadS3Od9Pte',
            'response' => $user_response
        );
        foreach($fields as $key=>$value)
        $fields_string .= $key . '=' . $value . '&';
        $fields_string = rtrim($fields_string, '&');

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, 'https://www.google.com/recaptcha/api/siteverify');
        curl_setopt($ch, CURLOPT_POST, count($fields));
        curl_setopt($ch, CURLOPT_POSTFIELDS, $fields_string);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, True);

        $result = curl_exec($ch);
        curl_close($ch);

        return json_decode($result, true);
    }

    // Call the function post_captcha
    $res = post_captcha($_POST['g-recaptcha-response']);

    if (!$res['success']) {
        // What happens when the CAPTCHA wasn't checked
        echo '<p>Please make sure you check the security CAPTCHA box.</p><br>';
    } else {
        // If CAPTCHA is successfully completed...

       
if(!$mail->Send())
{
echo "Message could not be sent. <p>";
echo "Mailer Error: " . $mail->ErrorInfo;
exit;
}

echo "We Appreciate Your Intrest. We’ll Get Back To You Soon!";
    }


?>