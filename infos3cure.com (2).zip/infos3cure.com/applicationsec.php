<!doctype html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0,maximum-scale=1.0, user-scalable=no">
<link rel="icon" href="images/fav.png">
<title>Infos3cure</title>
<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="css/bootstrap-slider.min.css">
<link rel="stylesheet" type="text/css" href="css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="css/slick.css">
<link rel="stylesheet" type="text/css" href="css/style-blue.css">
</head>

<body>

<div id="header-holder" class="inner-header color3-header web-hosting-page">
    <div class="whitebg"><img src="images/whitebg.svg" alt=""></div>
    <nav id="nav" class="navbar navbar-default navbar-full">
        <div class="container-fluid">
            <div class="container container-nav">
                <div class="row">
                    <div class="col-md-12">
                        <div class="navbar-header">
                            <button aria-expanded="false" type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs">
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                            </button>
                           <a class="logo-holder" href="index.php">
                                <div class="logo"></div>
                            </a>
                        </div>
                        <div style="height: 1px;" role="main" aria-expanded="false" class="navbar-collapse collapse" id="bs">
                             <ul class="nav navbar-nav navbar-right">
                                <li><a href="index.php">Home</a></li>
                                
                                   <li class="dropdown">
                                    <a href="index.php#features">Our Services  <i class="fa fa-caret-down"></i></a>
                                    <ul class="dropdown-menu">
                                      <li><a href="infrastructuresec.php">Infrastructure Security</a></li>
                                     <li><a href="applicationsec.php">Application Security</a></li>
                                     
                                    </ul>
                                </li>
                                 <li><a href="index.php#more-features">Our Promise</a></li>
                                  <li><a href="contact.php">Contact Us</a></li>
                               
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </nav>
    <div id="page-head" class="container-fluid inner-page">
        <div class="container">
            <div class="row">
                <div class="col-md-12 text-center">
                    <div class="page-title">Application Security</div>
                    <div id="page-icon">
                        <div class="pricing-icon pricing-color2">
                            <img src="images/password.png" style="margin-top: 10px;" alt="">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div id="h-info" class="container-fluid">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="info-text grey-text">A customized service that improves the security of applications and prevents security vulnerabilities. </div>
            </div>
        </div>
    </div>
</div>

<div id="apps" class="container-fluid">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="apps-holder">
                    <div class="apps-links-holder">
                        <div class="app-icon-holder app-icon-holder1 opened" data-id="1">
                            <div class="app-icon"><img class="grayscale" src="images/secure-data.png" alt="wordpress"></div>
                        </div>
                        <div class="app-icon-holder app-icon-holder2" data-id="2">
                            <div class="app-icon"><img class="brightness" src="images/computer.png" alt="joomla"></div>
                        </div>
                      
                    </div>
                    <div class="apps-details-holder">
                        <div class="app-details">
                            <div class="app-details1 show-details">
                               
                                <div class="col-md-12">
                                    <div class="app-title">Web Application Security and Penetration Testing</div>
                                    <div class="app-text">Web Application security assessment consists of black box testing approach followed by gray box testing. Within the black box testing, no information except the target IP / URL is provided to the penetration testers. Within the gray box testing approach, valid test credentials are used to log in to the application(s) to carry out the assessment test by imitating malicious application(s) user’s behavior.</div>
                                    <div class="app-text"> Runtime Vulnerability Assessment is an integral part to the process, which aims at detecting security vulnerabilities in the application through detailed examination of the application in a runtime environment.</div>
                                    <div class="app-text"> Several industry best practices are part of the overall application security testing including but not limited to OWASP Top 10, CIS Benchmarks and Best Practices.</div>
                                    
                                </div>
                            </div>
                            <div class="app-details2">
                                
                                <div class="col-md-12">
                                    <div class="app-title">Secure Code Analysis</div>
                                    <div class="app-text">Our security experts examine the source code of applications to identify programming and logical errors. The aim is to identify vulnerabilities before the applications are deployed based on business objectives, design and technologies used.</div>
                                    <div class="app-text">A blend of open source and commercial code analysis tools will be used followed by manual verification. Assessment experts consider the best practices from OWASP Proactive Controls and CIS Best Practices and our internal learnings.</div>
                                   
                                </div>
                            </div>
                            
                       



                           


                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<div id="message1" class="container-fluid message-area">
   
    <div class="container">
        <div class="row">
            <div class="col-sm-12 col-md-8">
                <div class="text-other-color4">Learn more about, </div>
                <div class="text-other-color3">INFOS3CURE's Application Security Services.</div>
            </div>
            <div class="col-sm-12 col-md-4">
                <div class="buttons-holder">
                    <a href="contact.php" class="ybtn ybtn-accent-color">Contact Us</a>
                </div>
            </div>
        </div>
    </div>
</div>


<div id="footer" class="container-fluid">
    <div class="container">
        <div class="row">
            <div class="col-md-3">
                <div class="address-holder">
                    <div class="phone"><i class="fa fa-phone"></i> <a href="tel:3174536991">(317) 453-6991</a></div>
                    <div class="email"><i class="fa fa-envelope"></i><a href="mailto:secure@INFOS3CURE"> secure@INFOS3CURE.com</a></div>
                       <div class="address">
                        <i class="fa fa-map-marker"></i> 
                        <div>26040 Acero, Suite 111<br>
                             Mission Viejo, CA <br>
                           92691, USA</div>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="footer-menu-holder">
                    <h4>Services</h4>
                    <ul class="footer-menu">
                        <li><a href="infrastructuresec.php">Infrastructure Security</a></li>
                        <li><a href="applicationsec.php">Application Security </a></li>
                        
                        
                    </ul>
                </div>
            </div>

                <div class="col-md-3">
                <div class="footer-menu-holder">
                    <h4>Company</h4>
                    <ul class="footer-menu">
                        <li><a href="privacypolicy.php">Privacy Policy</a></li>
                        <li><a href="termsuse.php">Terms of Use </a></li>
                        
                        
                    </ul>
                </div>
            </div>
            

            <div class="col-md-3">
                <div class="footer-menu-holder">
                    <h4>Partnerships</h4>
                    <a href="https://www.symantec.com/" target="_blank"><img src="images/secure-one-registered-partner-logo-global-registered.jpg"></a>
                   
                   
                </div>
            </div>
         
           
            <div class="col-xs-12"><hr>
               <div class="row">
               <div class="col-md-6 bottombar ">

                        <p>© 2018 All Rights Reserved |  <a href="http://infosharesystems.com/" target="_blank">Infoshare Systems Inc</a></p>
                        
                    </div>
                    <!--<div class="col-md-4  ">
                       
                            <div class="social-menu-holder">
                    <ul class="social-menu">
                        <li style="text-align: center;"><a href="#"><i class="fa fa-facebook"></i></a> | <a href="#"><i class="fa fa-linkedin"></i></a> | <a href="#"><i class="fa fa-twitter"></i></a></li>
                    </ul>
                </div>
                    </div>-->
                       <div class="col-md-6 bottombar">
                        <p>Powered By <a href="http://cloudmellow.com/" target="_blank">CloudMellow</a></p>
                    </div>
               </div>
            </div>
        </div>
    </div>
</div>
<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/bootstrap-slider.min.js"></script>
<script src="js/slick.min.js"></script>
<script src="js/main.js"></script>

<script type="text/javascript">
           //Contact Form
         $(function() {
           $('#signinform').submit(function(e) {
             e.preventDefault();
             console.log('Submitting');
             $.ajax({
               type: 'POST',
               url: 'php/subscription.php',
               data: new FormData($('#signinform')[0]),
               cache: false,
               contentType: false,
               processData: false,
               success: function(response) {
                 $('#get_in_touch_success2').html(response);
                  $("#signinform")[0].reset();
               }
             });
           });
         });
         </script>

</body>
</html>
